HERD Explorer data download

Source: NCSES Higher Education Research and Development (HERD) Survey public microdata, FY 2012-2024,
https://ncses.nsf.gov/explore-data/microdata/higher-education-research-development
Institution type (sector): Carnegie Classification of Institutions of Higher Education, 2021 update.
Not HERD data: the sector, msi and land_grant columns come from the Carnegie Classification, not the HERD Survey.
Carnegie data: American Council on Education, https://carnegieclassifications.acenet.edu, licensed CC BY-NC-SA 4.0
(noncommercial use, with attribution, shared under the same license): https://creativecommons.org/licenses/by-nc-sa/4.0/
Every other column is HERD data as NCSES released it. Data from other publishers (Census, BEA, IPEDS, GSS, Carnegie,
NSF EPSCoR, COGR) is only in the full database, in tables whose names start with context_; see its table_catalog table.
Dollar values are in whole nominal dollars. NCSES publishes HERD in thousands of dollars; HERD Explorer multiplies
by 1,000, so $1,234 thousand in an NCSES table is $1,234,000 here. Personnel values are people or full-time equivalents.
Measure definitions: measure_catalog sheet, or https://nate-layman.github.io/herd-explorer/data.html
Built on 2026-11-11 by HERD Explorer, https://github.com/nate-layman/herd-explorer

Disclaimer: HERD Explorer is an independent project. It is not an official product of NCSES or the U.S. National
Science Foundation, and neither NCSES, NSF nor the University of Idaho endorses it. The data are provided as is,
without warranty of any kind, and are not financial, budget, legal or investment advice. Check figures against the
official NCSES tables before relying on them. Report errors on the AI4RA Groups.io listserv, with #DataScience in
the subject line: https://groups.ai4ra.uidaho.edu/g/main
